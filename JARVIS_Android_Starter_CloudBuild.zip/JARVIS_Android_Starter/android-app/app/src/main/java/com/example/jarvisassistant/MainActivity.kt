package com.example.jarvisassistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JarvisApp() }
    }
}

@androidx.compose.runtime.Composable
fun JarvisApp() {
    val background = Color(0xFF070B14)
    val cyan = Color(0xFF45D9FF)
    val messages = remember {
        mutableStateListOf(
            ChatMessage("JARVIS online. I'm ready when you are.", false)
        )
    }
    val input = remember { mutableStateOf("") }
    val busy = remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = background) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF0B1830), background, Color(0xFF05070D))
                        )
                    )
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .background(Color(0xFF103349), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("J", color = cyan, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(modifier = Modifier.padding(start = 12.dp)) {
                        Text("J.A.R.V.I.S.", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text(
                            if (BuildConfig.DEMO_MODE) "SYSTEM ONLINE • DEMO MODE" else "SYSTEM ONLINE • AI MODE",
                            color = cyan,
                            fontSize = 10.sp,
                            letterSpacing = 1.2.sp
                        )
                    }
                }

                Spacer(Modifier.height(20.dp))

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xCC101B2B)),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("PERSONAL AI ASSISTANT", color = cyan, fontSize = 11.sp, letterSpacing = 1.5.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            if (BuildConfig.DEMO_MODE)
                                "Your interface is ready. Demo replies are enabled; connect a backend later for real AI."
                            else
                                "Ready to help with questions, ideas, and everyday tasks.",
                            color = Color(0xFFD8E6F4),
                            fontSize = 14.sp
                        )
                    }
                }

                Spacer(Modifier.height(14.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(messages) { message ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
                        ) {
                            Card(
                                modifier = Modifier.fillMaxWidth(0.88f),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (message.fromUser) Color(0xFF123D55) else Color(0xFF121C2B)
                                )
                            ) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(
                                        if (message.fromUser) "YOU" else "JARVIS",
                                        color = cyan,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(Modifier.height(4.dp))
                                    Text(message.text, color = Color(0xFFF0F6FC), fontSize = 15.sp)
                                }
                            }
                        }
                    }
                    if (busy.value) {
                        item { Text("JARVIS is thinking…", color = cyan, fontSize = 13.sp) }
                    }
                }

                Spacer(Modifier.height(12.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF111B2A), RoundedCornerShape(18.dp))
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = input.value,
                        onValueChange = { input.value = it },
                        modifier = Modifier.weight(1f).padding(8.dp),
                        textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp),
                        cursorBrush = Brush.verticalGradient(listOf(cyan, cyan)),
                        decorationBox = { inner ->
                            if (input.value.isEmpty()) {
                                Text("Ask JARVIS something…", color = Color(0xFF8193A8), fontSize = 14.sp)
                            }
                            inner()
                        }
                    )
                    Button(
                        onClick = {
                            val question = input.value.trim()
                            if (question.isNotEmpty() && !busy.value) {
                                input.value = ""
                                messages.add(ChatMessage(question, true))
                                busy.value = true
                                scope.launch {
                                    val answer = if (BuildConfig.DEMO_MODE) {
                                        demoReply(question)
                                    } else {
                                        withContext(Dispatchers.IO) { askBackend(question) }
                                    }
                                    messages.add(ChatMessage(answer, false))
                                    busy.value = false
                                }
                            }
                        },
                        enabled = input.value.isNotBlank() && !busy.value,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF087EA4)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Filled.Send, contentDescription = "Send")
                    }
                }

                Spacer(Modifier.height(8.dp))
                Text(
                    "Prototype • AI can make mistakes • You control what you share",
                    color = Color(0xFF718198),
                    fontSize = 10.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
            }
        }
    }
}

private fun demoReply(question: String): String {
    val q = question.lowercase()
    return when {
        "hello" in q || "hi" in q -> "Hello! I'm JARVIS, your assistant prototype. Once connected to an AI backend, I'll be able to answer a much wider range of questions."
        "your name" in q -> "I'm JARVIS — currently running in demo mode."
        "time" in q -> "I don't have live device-time access in this demo yet. That's a good feature for our next version."
        else -> "I received your message: \"$question\". This is a demo response, not a real AI answer yet. We'll connect the secure backend in the next step."
    }
}

private fun askBackend(question: String): String {
    return try {
        val url = URL(BuildConfig.BACKEND_BASE_URL + "chat")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        val body = JSONObject().put("message", question).toString()
        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val status = connection.responseCode
        val stream = if (status in 200..299) connection.inputStream else connection.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        connection.disconnect()
        if (status in 200..299) {
            JSONObject(response).optString("reply", "The server returned no reply.")
        } else {
            "Backend error ($status): ${JSONObject(response).optString("error", response)}"
        }
    } catch (e: Exception) {
        "I couldn't reach the backend. Check that the server is running and the backend address is correct. Details: ${e.message ?: "connection failed"}"
    }
}
