JARVIS Android Starter — beginner guide
=======================================

WHAT THIS ZIP CONTAINS
- android-app/: a simple native Android chat app project (Kotlin + Jetpack Compose)
- backend/: a small Node.js server that keeps the AI API key off the phone
- The Android app can run in DEMO mode without an API key or internet connection.
- Real AI mode needs a backend running on your PC and an API provider account. API usage may cost money.

IMPORTANT SECURITY
Never put an AI API key in Android code, in the APK, or in a file you send to someone.
The backend reads OPENAI_API_KEY from an environment variable.
Do not share your key in ChatGPT, screenshots, or chat messages.

PART A — BUILD THE ANDROID APK
1. On your Windows PC, install Android Studio from:
   https://developer.android.com/studio
2. Extract this ZIP to a normal folder, for example Documents\JARVIS_Android_Starter.
3. Open Android Studio.
4. Choose "Open" and select the android-app folder inside the extracted folder.
5. Wait for Gradle sync. If Android Studio asks to install Android SDK components, accept the recommended components.
6. To build an installable APK, select Build > Build Bundle(s) / APK(s) > Build APK(s).
7. When it finishes, click "locate" in the notification. The debug APK is normally:
   android-app/app/build/outputs/apk/debug/app-debug.apk
8. Copy that APK to your Android phone and open it. If Android asks, allow installation from that file manager for this install.
   Only install APKs you built or trust.

If the app doesn't build:
- Check that Android Studio has internet access to download Gradle dependencies.
- Use the Gradle JDK bundled with Android Studio (Settings > Build, Execution, Deployment > Build Tools > Gradle).
- Send me the exact error text or a screenshot and I can help troubleshoot.

PART B — TRY THE APP IN DEMO MODE
The app starts in DEMO mode. Type a message and press Send. It will reply with a simple sample response. This proves the app UI works before you set up AI access.

PART C — OPTIONAL REAL AI BACKEND (NOT REQUIRED TO BUILD THE APK)
1. Install Node.js LTS from https://nodejs.org/ .
2. Open a terminal / Command Prompt in the backend folder.
3. Run:
      npm install
4. Create a copy of .env.example named .env.
5. Open .env in a text editor and set OPENAI_API_KEY to your own API key.
   Never put the key in Android code. Never upload .env anywhere.
6. Start the backend:
      npm start
7. It runs on your PC at http://localhost:3000 by default.
8. To test from the same PC, open http://localhost:3000/health in a browser. It should show {"ok":true}.
9. To connect the phone, the phone and PC must be on the same trusted Wi-Fi network. In app/build.gradle.kts, change BACKEND_BASE_URL from
   "http://10.0.2.2:3000/" to "http://YOUR_PC_LAN_IP:3000/".
   Find the PC LAN IPv4 address with `ipconfig` in Command Prompt.
   Then rebuild the APK. Do not use a public network or port-forward this development server.
   Android cleartext HTTP is enabled only for this local development starter. Do not deploy this configuration publicly.
10. Real AI calls require an API account with billing configured. Check the provider's current pricing first:
    https://developers.openai.com/api/docs/pricing

NOTES
- The Android emulator uses 10.0.2.2 to reach the host PC. A physical phone needs the PC's LAN IP.
- This starter is a learning prototype, not a production-ready public service.
- It does not include always-listening voice activation, background monitoring, or unrestricted phone control.
- AI responses are generated remotely and may be inaccurate.


PART D — OPTIONAL GITHUB CLOUD BUILD
This project includes .github/workflows/android.yml for a GitHub Actions build.
To use it, upload the project contents to a GitHub repository (the android-app folder and .github folder must be at the repository root).
Then open the repository's Actions tab and run "Build JARVIS APK" if it has not run automatically.
When the workflow finishes successfully, open the run, find Artifacts, and download jarvis-debug-apk. Extract the artifact ZIP to get app-debug.apk.
Note: GitHub UI varies on mobile. Never share your GitHub password or recovery codes. Review workflow files before running them.
